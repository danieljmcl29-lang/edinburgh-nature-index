---
title: Edinburgh Nature Equitable Access Index
emoji: 🌳
colorFrom: green
colorTo: blue
sdk: docker
app_port: 7860
pinned: false
short_description: Network-based greenspace accessibility and deprivation explorer for Edinburgh
---

# Edinburgh Nature Equitable Access Index (NEAI)

Streamlit application for exploring modelled road-network access to greenspaces against Scottish Index of Multiple Deprivation (SIMD) indicators.

## Publishing on Hugging Face Spaces

1. Sign in to https://huggingface.co/new-space and create a **Docker** Space named `edinburgh-nature-index`. Set visibility to Public if you want everyone to be able to use it.
2. Upload **all files from this directory** to the Space repository, keeping the `.streamlit` folder. Hugging Face will build the Docker image and run the app on port 7860.
3. Open its **App** tab and check the green build state; if deployment fails inspect the **Logs** tab.
4. Share the actual Space URL shown in the browser, or open **Embed this Space** to find the direct `hf.space` address.

Docker Spaces require a paid eligible Hugging Face plan according to their October 2026 documentation. A custom domain requires PRO/Team/Enterprise and a domain you own. Configure it in Space **Settings > Custom Domain**, then set a CNAME pointing at `hf.space` as instructed by Hugging Face.

## Data caveats

The application starts with **synthetic data**, which is not evidence about real Edinburgh greenspace provision. Use the **Real OS / SIMD GeoPackages** option to upload suitable datasets. Uploaded files belong to the current browser session and are not bundled in the Space. File formats, layers, IDs and permitted access need to be validated. Avoid uploading confidential or improperly licensed data.

OS Open Roads provides an indicative network, not an authoritative pedestrian routing network. Outputs do not measure vegetation quality, safety or environmental justice directly.

## Run locally

```bash
pip install -r requirements.txt
streamlit run app.py
```

Or use Docker:

```bash
docker build -t neai .
docker run -p 7860:7860 neai
```
