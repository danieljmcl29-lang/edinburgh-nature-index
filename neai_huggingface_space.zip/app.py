"""Edinburgh Nature Equitable Access Index (NEAI).

Research prototype: synthetic demonstration or uploaded OS/SIMD GeoPackages.
Distances describe an indicative road-network model, not verified walking routes.
"""
from __future__ import annotations

import io
import math
import hashlib
import tempfile
from pathlib import Path

import folium
import geopandas as gpd
import networkx as nx
import numpy as np
import pandas as pd
import plotly.express as px
import streamlit as st
from scipy.spatial import cKDTree
from scipy.stats import spearmanr
from shapely.geometry import Point
from streamlit_folium import st_folium

CRS = "EPSG:27700"
st.set_page_config(page_title="Edinburgh Nature Equitable Access Index", layout="wide")
st.title("Edinburgh Nature Equitable Access Index")
st.caption("Scenario-based model of greenspace accessibility and socioeconomic deprivation")


def column_matching(df, candidates):
    found = {str(c).lower(): c for c in df.columns}
    return next((found[k.lower()] for k in candidates if k.lower() in found), None)


def as_points(frame):
    result = frame.copy()
    result.geometry = result.geometry.representative_point()
    return result


def normalize_sites(sites):
    sites = sites.to_crs(CRS).copy()
    sites = sites[sites.geometry.notna() & ~sites.geometry.is_empty].copy()
    if sites.empty:
        raise ValueError("Greenspace dataset contains no usable geometries.")
    identifier = column_matching(sites, ["toid", "id", "site_id", "greenspaceid", "fid"])
    sites["site_id"] = sites[identifier].astype(str) if identifier else [f"site_{i}" for i in range(len(sites))]
    sites["site_id"] = sites["site_id"].astype(str)
    # OS Open Greenspace sites normally consist of polygons in projected coordinates.
    if sites.geometry.geom_type.isin(["Polygon", "MultiPolygon"]).any():
        sites["area_ha"] = sites.geometry.area / 10000.0
    else:
        area_field = column_matching(sites, ["area_ha"])
        sites["area_ha"] = pd.to_numeric(sites[area_field], errors="coerce") if area_field else np.nan
    return sites


def demo_data(seed=42, n_zones=120, n_sites=300, grid_n=42):
    rng = np.random.default_rng(seed)
    minx, miny, maxx, maxy = 318000, 663000, 334000, 677000
    centroids = [Point(x, y) for x, y in zip(rng.uniform(minx, maxx, n_zones), rng.uniform(miny, maxy, n_zones))]
    ranks = rng.choice(np.arange(1, 6977), size=n_zones, replace=False)
    zones = gpd.GeoDataFrame({
        "DataZone": [f"DEMO_{i:04d}" for i in range(n_zones)],
        "SIMD_rank": ranks,
        "SIMD_decile": np.ceil(ranks * 10 / 6976).astype(int).clip(1, 10),
        "Population": rng.integers(400, 1200, size=n_zones),
    }, geometry=centroids, crs=CRS)
    sites = gpd.GeoDataFrame({
        "site_id": [f"G_{i:04d}" for i in range(n_sites)],
        "function": rng.choice(["Public Park", "Playing Field", "Play Space", "Amenity Greenspace"], size=n_sites),
        "area_ha": np.round(rng.exponential(1.2, n_sites) + .05, 3),
    }, geometry=[Point(x, y) for x, y in zip(rng.uniform(minx, maxx, n_sites), rng.uniform(miny, maxy, n_sites))], crs=CRS)
    access = sites[["site_id", "geometry"]].copy()
    gx, gy = np.linspace(minx, maxx, grid_n), np.linspace(miny, maxy, grid_n)
    graph = nx.Graph()
    for row in range(grid_n):
        for col in range(grid_n):
            node = (float(gx[col]), float(gy[row]))
            graph.add_node(node)
            for other in ((col - 1, row), (col, row - 1)):
                if other[0] >= 0 and other[1] >= 0:
                    target = (float(gx[other[0]]), float(gy[other[1]]))
                    graph.add_edge(node, target, weight=math.dist(node, target))
    return sites, access, zones, graph


def read_gpkg(upload, layer=None):
    # Uploaded file objects are not local file paths, so write a temporary copy.
    with tempfile.TemporaryDirectory() as folder:
        path = Path(folder) / "input.gpkg"
        path.write_bytes(upload.getvalue())
        return gpd.read_file(path, layer=layer) if layer else gpd.read_file(path)


def load_real(sites_file, access_file, roads_file, simd_file, simd_csv):
    sites = normalize_sites(read_gpkg(sites_file, "GreenspaceSite"))
    if access_file is not None:
        access = read_gpkg(access_file, "AccessPoint").to_crs(CRS)
        access = access[access.geometry.notna() & ~access.geometry.is_empty].copy()
        site_link = column_matching(access, ["refToGreenspaceSite", "refToGSite", "site_id", "greenspacesiteid", "greenspace_site_id", "siteid"])
        if site_link is None:
            raise ValueError("AccessPoint layer requires a site-reference attribute such as site_id. Inspect your OS schema and adapt the mapping.")
        access["site_id"] = access[site_link].astype(str)
        access_type_col = column_matching(access, ["accessType", "access_type"])
        if access_type_col:
            # Exclude motor-vehicle-only entrances from a walking-access model.
            access = access[access[access_type_col].astype(str).str.contains("Pedestrian", case=False, na=False)].copy()
        access = as_points(access)
        access = access[access["site_id"].isin(sites["site_id"])].copy()
        if access.empty:
            raise ValueError("No AccessPoint identifiers match GreenspaceSite identifiers. Check the OS relationship fields.")
    else:
        # Polygon representative points are explicitly an imperfect fallback.
        access = as_points(sites[["site_id", "geometry"]])
    roads = read_gpkg(roads_file, "RoadLink").to_crs(CRS)
    zones = read_gpkg(simd_file).to_crs(CRS)
    if zones.empty or roads.empty:
        raise ValueError("Road or SIMD dataset is empty.")
    dz_col = column_matching(zones, ["DataZone", "Data_Zone", "DataZone2011", "DZ_CODE", "dz11cd", "dzcode"])
    if dz_col is None:
        raise ValueError("Cannot find the DataZone identifier in the SIMD boundaries. Rename its field to DataZone.")
    zones["DataZone"] = zones[dz_col].astype(str)
    if simd_csv is not None:
        stats = pd.read_csv(simd_csv)
        dz_stats = column_matching(stats, ["DataZone", "Data_Zone", "DataZone2011", "DZ_CODE", "dz11cd", "dzcode"])
        if dz_stats is None:
            raise ValueError("SIMD CSV needs a DataZone column to join to polygons.")
        stats["DataZone"] = stats[dz_stats].astype(str)
        possible = [c for c in stats.columns if c != "DataZone" and c not in zones.columns]
        zones = zones.merge(stats[["DataZone"] + possible].drop_duplicates("DataZone"), on="DataZone", how="left")
    rank_col = column_matching(zones, ["SIMD_rank", "SIMD2020v2_Rank", "SIMD2020_Rank", "SIMD2020V2Rank", "SIMD2020Rank", "SIMD2020v2_Rank_1"])
    decile_col = column_matching(zones, ["SIMD_decile", "SIMD2020v2_Decile", "SIMD2020_Decile"])
    zones["SIMD_rank"] = pd.to_numeric(zones[rank_col], errors="coerce") if rank_col else np.nan
    zones["SIMD_decile"] = pd.to_numeric(zones[decile_col], errors="coerce") if decile_col else np.ceil(zones["SIMD_rank"] * 10 / 6976)
    population_col = column_matching(zones, ["Population", "Total_Population", "TotalPopulation", "pop"])
    zones["Population"] = pd.to_numeric(zones[population_col], errors="coerce") if population_col else np.nan
    zones = as_points(zones)
    graph = nx.Graph()
    for geom in roads.geometry.dropna():
        if geom.is_empty:
            continue
        lines = [geom] if geom.geom_type == "LineString" else list(geom.geoms) if geom.geom_type == "MultiLineString" else []
        for line in lines:
            coords = list(line.coords)
            for a, b in zip(coords[:-1], coords[1:]):
                a, b = (float(a[0]), float(a[1])), (float(b[0]), float(b[1]))
                if a != b:
                    graph.add_edge(a, b, weight=math.dist(a, b))
    if graph.number_of_nodes() == 0:
        raise ValueError("No routable RoadLink geometries were found.")
    return sites, access, zones, graph


source = st.sidebar.radio("Data source", ["Synthetic demonstration", "Real OS / SIMD GeoPackages"])
if source == "Synthetic demonstration":
    sites, access, zones, graph = demo_data()
    st.warning("SYNTHETIC DATA: All locations, deprivation indicators and scores in this mode are illustrative, not findings about Edinburgh.")
else:
    st.sidebar.info("Upload GeoPackage files, with layers named GreenspaceSite, AccessPoint and RoadLink as appropriate. Access points are recommended.")
    sites_file = st.sidebar.file_uploader("GreenspaceSite GeoPackage", type="gpkg")
    access_file = st.sidebar.file_uploader("AccessPoint GeoPackage (optional fallback to interior site points)", type="gpkg")
    roads_file = st.sidebar.file_uploader("RoadLink GeoPackage", type="gpkg")
    simd_file = st.sidebar.file_uploader("SIMD data-zone boundaries GeoPackage", type="gpkg")
    simd_csv = st.sidebar.file_uploader("SIMD indicators CSV (optional if included in boundaries)", type="csv")
    if not all([sites_file, roads_file, simd_file]):
        st.info("Upload the required files in the sidebar to run the real-data model.")
        st.stop()
    try:
        sites, access, zones, graph = load_real(sites_file, access_file, roads_file, simd_file, simd_csv)
    except Exception as exc:
        st.error(f"Unable to load data: {exc}")
        st.stop()
    if access_file is None:
        st.warning("AccessPoint file absent: using representative points inside site polygons. Results do not represent verified park entrances.")
    st.warning("RoadLink connectivity is approximate: intersections without common vertices are not connected; pedestrian-only routes, access restrictions and barriers require validation.")

st.sidebar.header("Scenario controls")
threshold = st.sidebar.slider("Maximum modelled distance (metres)", 200, 2000, 800, 100)
min_size = st.sidebar.slider("Minimum greenspace area (hectares)", 0.0, 5.0, 0.2, 0.1)
w_prox = st.sidebar.slider("Proximity weight (remainder = provision)", 0., 1., .5, .05)
max_snap = st.sidebar.slider("Maximum acceptable snap distance (metres)", 50, 1000, 300, 50)

node_list = list(graph.nodes())
xy = np.asarray(node_list, dtype=float)
tree = cKDTree(xy)

def snap_coords(points):
    coords = np.array([[p.x, p.y] for p in points])
    distances, indices = tree.query(coords)
    return [node_list[int(i)] for i in indices], np.asarray(distances)

qualifying = sites[sites["area_ha"].fillna(-1) >= min_size]
entrances = access[access["site_id"].isin(qualifying["site_id"])].copy()
if entrances.empty:
    st.error("No accessible site entry points pass the minimum area filter. Check greenspace IDs and the size threshold.")
    st.stop()

entrance_nodes, entrance_snap = snap_coords(entrances.geometry)
entrances["node"] = entrance_nodes
entrances["snap_m"] = entrance_snap
entrances = entrances[entrances["snap_m"] <= max_snap].copy()
zone_nodes, zone_snap = snap_coords(zones.geometry)

# Each greenspace counts once even if it has many entrance points.
node_sites = {}
for _, r in entrances.iterrows():
    node_sites.setdefault(r["node"], set()).add(str(r["site_id"]))

@st.cache_data(show_spinner="Calculating network accessibility…")
def calculate(_graph, graph_key, zone_nodes_key, site_nodes_key, threshold_m, zone_snap_key, snap_limit):
    output = []
    node_sites_local = {node: set(ids) for node, ids in site_nodes_key}
    for origin, snap_m in zip(zone_nodes_key, zone_snap_key):
        if snap_m > snap_limit:
            output.append((0., 0., np.nan, 0, False))
            continue
        lengths = nx.single_source_dijkstra_path_length(_graph, origin, cutoff=threshold_m, weight="weight")
        reached = {}
        for node, distance in lengths.items():
            if node in node_sites_local:
                for sid in node_sites_local[node]:
                    reached[sid] = min(reached.get(sid, float("inf")), distance)
        nearest = min(reached.values(), default=float("inf"))
        proximity = 1 - nearest / threshold_m if math.isfinite(nearest) else 0.
        provision = min(len(reached) / 5., 1.)
        output.append((proximity, provision, nearest if math.isfinite(nearest) else np.nan, len(reached), True))
    return output

# Identify the network and entrance assignment so cache keys cannot silently reuse stale scores.
network_signature = hashlib.sha256(repr((graph.number_of_nodes(), graph.number_of_edges(), sorted(graph.edges(data="weight"), key=lambda x: repr(x)))).encode()).hexdigest()
site_key = tuple(sorted(((node, tuple(sorted(ids))) for node, ids in node_sites.items()), key=lambda x: repr(x[0])))
results = calculate(graph, network_signature, tuple(zone_nodes), site_key, threshold, tuple(np.round(zone_snap, 4)), max_snap)
zones = zones.copy()
zones[["proximity", "provision", "nearest_m", "reachable_sites", "valid_snap"]] = pd.DataFrame(results, index=zones.index)
zones["NEAI"] = w_prox * zones["proximity"] + (1 - w_prox) * zones["provision"]
zones.loc[~zones["valid_snap"], "NEAI"] = np.nan
zones["origin_snap_m"] = zone_snap

valid = zones.dropna(subset=["NEAI"])
if valid.empty:
    st.error("No data zones can be analysed at this snapping threshold.")
    st.stop()

c1, c2, c3 = st.columns(3)
c1.metric("Data zones analysed", f"{len(valid):,}/{len(zones):,}")
c2.metric("Mean NEAI (unweighted)", f"{valid['NEAI'].mean():.2f}")
c3.metric("Qualifying greenspaces", f"{qualifying['site_id'].nunique():,}")
st.caption("NEAI = proximity weight × (1 − nearest reachable distance / threshold) + (1 − proximity weight) × min(distinct reachable sites / 5, 1). Unreachable zones score zero; zones that cannot be snapped reliably are excluded.")

selected = st.multiselect("Inspect data zones (leave blank for all)", zones["DataZone"].tolist(), default=[])
subset = valid[valid["DataZone"].isin(selected)] if selected else valid
st.subheader("Map: modelled greenspace accessibility")
map_obj = folium.Map(location=[55.9533, -3.1883], zoom_start=11, tiles="cartodbpositron")
for _, r in subset.to_crs(4326).iterrows():
    score = float(r["NEAI"])
    red = int(220 * (1 - score) + 35)
    green = int(180 * score + 35)
    colour = f"#{red:02x}{green:02x}60"
    folium.CircleMarker(
        location=[r.geometry.y, r.geometry.x], radius=5, color=colour,
        fill=True, fill_color=colour, fill_opacity=.85,
        popup=folium.Popup(f"Zone: {r['DataZone']} | NEAI: {score:.2f} | Reachable sites: {int(r['reachable_sites'])}", max_width=320),
    ).add_to(map_obj)
st_folium(map_obj, width=None, height=490, returned_objects=[])

st.subheader("Equity comparison")
comparison = valid.dropna(subset=["SIMD_rank"])
if len(comparison) >= 3 and comparison["SIMD_rank"].nunique() > 1 and comparison["NEAI"].nunique() > 1:
    left, right = st.columns(2)
    with left:
        st.plotly_chart(px.scatter(comparison, x="SIMD_rank", y="NEAI", hover_data=["DataZone"],
                                   title="NEAI versus SIMD rank (low rank = higher deprivation)"), use_container_width=True)
    with right:
        plot_data = comparison.dropna(subset=["SIMD_decile"]).copy()
        plot_data["SIMD_decile"] = plot_data["SIMD_decile"].astype(int).astype(str)
        st.plotly_chart(px.box(plot_data, x="SIMD_decile", y="NEAI", title="NEAI by SIMD decile"), use_container_width=True)
    rho, p = spearmanr(comparison["SIMD_rank"], comparison["NEAI"])
    st.metric("Spearman rank correlation", f"{rho:.3f}")
    st.caption(f"Exploratory correlation, two-sided p-value: {p:.3g}; n={len(comparison)}. Spatial dependence and other confounders are not accounted for; this is not a causal test.")
else:
    st.info("Supply suitable SIMD ranking attributes to enable the deprivation comparison.")

st.subheader("Download results")
export = zones.drop(columns=["geometry"]).copy()
st.download_button("Download CSV", export.to_csv(index=False).encode("utf-8"), "neai_results.csv", "text/csv")
geojson = zones.to_crs("EPSG:4326").to_json()
st.download_button("Download GeoJSON (WGS84)", geojson, "neai_results.geojson", "application/geo+json")
with st.expander("Method and limitations"):
    st.write("This index uses an indicative road network, green-space area threshold, and data-zone representative points. "
             "It does not measure biodiversity, perceived safety, accessible entrances, green-space quality, route legality, "
             "slope, road crossings, opening hours, or population-weighted exposure. OS Open Roads can omit footpaths; "
             "OS network junctions and entrance-to-network connections require verification. "
             "The five-site saturation constant and all slider defaults are researcher-selected modelling assumptions. "
             "Real-data results should be validated against known walking routes before use in academic conclusions.")
